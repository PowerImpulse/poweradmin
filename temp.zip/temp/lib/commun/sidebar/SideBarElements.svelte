<script>
  import SidebarMenuAreas from "./SidebarMenuAreas.svelte";
  import SidebarLogoTop from "$lib/commun/sidebar/SidebarLogoTop.svelte";
</script>

<SidebarLogoTop />
<SidebarMenuAreas />


