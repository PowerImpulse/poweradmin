<div class="icc">
    <span><a href="/">TENIS</a></span>
</div>
<style>
    div{
      height: 60px;
      display: flex;
      text-align: center;
    }
</style>