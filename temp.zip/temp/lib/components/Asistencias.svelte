<script lang="ts">
    import { initializeApp, getApps, getApp } from "firebase/app";
    import { collection, onSnapshot, getFirestore, doc, updateDoc, deleteDoc, addDoc } from "firebase/firestore";
    import { dbTimeRecord } from "$lib/firebase/client"; // Asegúrate de que db es la referencia correcta a tu Firestore

    const timeRecordRef = collection(dbTimeRecord , "time_record");

    let asistencias: any[] = [];

    onSnapshot(timeRecordRef, (querySnapshot) => {
        let listaAsistencias: any[] = [];
        querySnapshot.forEach((doc) => {
            let asistencia = { ...doc.data(), uid: doc.id };
            listaAsistencias.push(asistencia);
        });
        asistencias = listaAsistencias;
        // console.log(asistencias);
    });

    let description = "";
    let endImagePath = "";
    let endImageUrl = "";
    let endLatitude = "";
    let endLongitude = "";
    let endLocation = "";
    let endTime = "";
    let imageUrl = "";
    let startImagePath = "";
    let startLatitude = "";
    let startLocation = "";
    let startLongitude = "";
    let startTime = "";
    let userId = "";
    let error = "";

    const crearAsistencia = async () => {
        if (description.trim() !== "" && startTime.trim() !== "" && userId.trim() !== "") {
            try {
                await addDoc(timeRecordRef, {
                    description: description,
                    endImagePath: endImagePath,
                    endImageUrl: endImageUrl,
                    endLatitude: endLatitude,
                    endLongitude: endLongitude,
                    endLocation: endLocation,
                    endTime: endTime,
                    imageUrl: imageUrl,
                    startImagePath: startImagePath,
                    startLatitude: startLatitude,
                    startLocation: startLocation,
                    startLongitude: startLongitude,
                    startTime: startTime,
                    userId: userId,
                });
                error = "";
            } catch (e: any) {
                error = `Error al crear asistencia: ${e.message}`;
            }
        } else {
            error = "Los campos descripción, hora de inicio y userId son obligatorios";
        }
        description = "";
        endImagePath = "";
        endImageUrl = "";
        endLatitude = "";
        endLongitude = "";
        endLocation = "";
        endTime = "";
        imageUrl = "";
        startImagePath = "";
        startLatitude = "";
        startLocation = "";
        startLongitude = "";
        startTime = "";
        userId = "";
    };

    const eliminarAsistencia = async (uid: string) => {
        try {
            await deleteDoc(doc(dbTimeRecord , "time_record", uid));
        } catch (e: any) {
            error = `Error al eliminar asistencia: ${e.message}`;
        }
    };

    const teclaPresionada = (e: KeyboardEvent) => {
        if (e.key === "Enter") {
            crearAsistencia();
        }
    };
</script>

<a href="/asistencias">Asistencias</a>
<hr />
<br />
<div>
    <input type="text" placeholder="Descripción" bind:value={description} />
    <input type="text" placeholder="Imagen de finalización" bind:value={endImagePath} />
    <input type="text" placeholder="URL de imagen de finalización" bind:value={endImageUrl} />
    <input type="text" placeholder="Latitud de finalización" bind:value={endLatitude} />
    <input type="text" placeholder="Longitud de finalización" bind:value={endLongitude} />
    <input type="text" placeholder="Ubicación de finalización" bind:value={endLocation} />
    <input type="datetime-local" placeholder="Hora de finalización" bind:value={endTime} />
    <input type="text" placeholder="URL de imagen" bind:value={imageUrl} />
    <input type="text" placeholder="Imagen de inicio" bind:value={startImagePath} />
    <input type="text" placeholder="Latitud de inicio" bind:value={startLatitude} />
    <input type="text" placeholder="Ubicación de inicio" bind:value={startLocation} />
    <input type="text" placeholder="Longitud de inicio" bind:value={startLongitude} />
    <input type="datetime-local" placeholder="Hora de inicio" bind:value={startTime} />
    <input type="text" placeholder="ID de usuario" bind:value={userId} />
    <button on:click={crearAsistencia}>Agregar</button>
</div>

<ul>
    {#each asistencias as asistencia (asistencia.uid)}
        <li class="p-4">
            <span>Descripción: {asistencia.description}</span> -
            <span>Entrada: {asistencia.startTime.toDate().toLocaleDateString()}</span> -
            <span>Salida: {asistencia.endTime}</span>
            <span>
                <button on:click={() => eliminarAsistencia(asistencia.uid)}>
                    Eliminar
                </button>
            </span>
        </li>
    {:else}
        No hay asistencias
    {/each}
    <p class="error">{error}</p>
</ul>

<svelte:window on:keydown={teclaPresionada} />

<hr />
<br />

<style>
    .error {
        color: red;
    }
</style>
