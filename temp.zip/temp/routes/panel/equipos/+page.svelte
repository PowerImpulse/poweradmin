<script>
import Equipos from "$lib/components/Equipos.svelte"
</script>

<h1>Equipos</h1>

<Equipos />