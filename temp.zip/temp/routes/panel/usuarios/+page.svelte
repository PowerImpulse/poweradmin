<script>
    import Usuarios from "$lib/components/Usuarios.svelte" 
</script>

<h1>Usuarios</h1>

<Usuarios />