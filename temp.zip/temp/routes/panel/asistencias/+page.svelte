<script>
    import Asistencias from "$lib/components/Asistencias.svelte";
</script>

<h1>Asistencias</h1>

<Asistencias />