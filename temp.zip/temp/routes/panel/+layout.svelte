<h1>Panel Layout</h1>
<a href="/">Inicio</a> <a href="/panel/equipos">Equipos</a> <a href="/panel/usuarios">Usuarios</a>  <a href="/panel/asistencias">Asistencias</a>
<slot/>