<script>
    import { AirplayIcon, AtSignIcon} from 'svelte-feather-icons'
    import Header from "$lib/commun/header/PublicHeader.svelte"
    import SubMenu from '$lib/commun/header/submenu/SubMenu.svelte';
</script>

     

<section>
  <div>  <h1 class="bg-blue-300" >Login</h1>
    <a href="/panel">Acceder</a>
  </div>

</section>



<style>
  section{
    display: flex;
  }
</style>
  