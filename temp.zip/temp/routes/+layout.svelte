<script>
    import "$lib/assets/css/global.css"
</script>

<slot/> 
